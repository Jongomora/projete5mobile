package com.example.myapplication;

public class param {
    public static int idUser = 0;
}
