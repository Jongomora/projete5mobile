package com.example.myapplication;

public interface Login {
}
